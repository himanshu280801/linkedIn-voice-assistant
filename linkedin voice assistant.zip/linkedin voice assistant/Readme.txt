Title
    LinkedIn voice assistant.
Summary
    Use LinkedIn with voice commands.